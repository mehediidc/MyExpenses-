# MyExpenses – Native JSON Backup/Restore

This project keeps the existing offline MyExpenses HTML/SQLite application and replaces the unreliable WebView download method with Android's Storage Access Framework.

## Backup
Tap the 💾 button. Android opens **Save to...**. Choose Downloads, Files, Google Drive, SD card, etc.

## Restore
Open **History → Backup / Restore Data → Restore Backup File** and select the `.json` backup.

No broad storage permission is required. The Android system file picker grants access only to the file the user chooses.

## Build
Push this folder to GitHub. The included GitHub Actions workflow builds `app-debug.apk` automatically. Download it from the workflow run's **Artifacts** section.

The app targets Android 9/API 28 and above, while the minimum supported Android version is API 21.
