package org.apache.cordova;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Lightweight native shell for MyExpenses.
 * It keeps the existing offline HTML/SQLite app and adds a real Android
 * Storage Access Framework bridge for JSON backup/restore.
 */
public class CordovaActivity extends Activity {
    private static final int REQ_SAVE = 4101;
    private static final int REQ_OPEN = 4102;
    private WebView webView;
    private String pendingBackupJson;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBackup");
            webView.destroy();
        }
        super.onDestroy();
    }

    private void chooseSave(String json, String requestedName) {
        pendingBackupJson = json;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, requestedName);
        startActivityForResult(i, REQ_SAVE);
    }

    private void chooseOpen() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
        startActivityForResult(i, REQ_OPEN);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = null;
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_SAVE) {
                if (pendingBackupJson == null) return;
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new Exception("Could not open selected file");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackupJson = null;
                runJs("if(window.onNativeBackupSaved) window.onNativeBackupSaved(true);");
            } else if (requestCode == REQ_OPEN) {
                String text;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Could not open backup file");
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] tmp = new byte[8192];
                    int n;
                    while ((n = in.read(tmp)) != -1) buffer.write(tmp, 0, n);
                    text = buffer.toString("UTF-8");
                }
                final String safe = org.json.JSONObject.quote(text);
                runJs("if(window.onAndroidBackupLoaded) window.onAndroidBackupLoaded(" + safe + ");");
            }
        } catch (Exception e) {
            final String msg = e.getMessage() == null ? "File operation failed" : e.getMessage().replace("\\", "\\\\").replace("'", "\\'");
            runJs("alert('" + msg + "');");
        }
    }

    private void runJs(final String script) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript("javascript:(function(){" + script + "})();", null));
    }

    public class BackupBridge {
        @JavascriptInterface public void saveBackup(String json, String filename) {
            if (json == null) return;
            chooseSave(json, filename == null || filename.length() == 0 ? "MyExpenses-Backup.json" : filename);
        }
        @JavascriptInterface public void restoreBackup() { chooseOpen(); }
    }
}
